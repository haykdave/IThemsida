# Modelling logical gates

You have been given a small library for modelling logical gates,
i.e. components which, given a specific number of input bits (`1`
or `0`) produces one or more output bits. An example of a logical
gate is the AND gate which reads two bits and produces `1` if both
the input bits are `1`, and otherwise `0`. We can draw an AND gate
like this:

           +-------+
    -------|       |
           |  AND  |----
    -------|       |
           +-------+

In this library, we call one or more bits on parallel wires a
*signal*. In other words, the AND gate reads a signal of width 2
(for example `11`) and produces a signal of width 1 (for example
`1`). Signals are modelled using the `Signal` class, and the
`read` method returns individual bits as `boolean`s given an
index. For example, if `s` is the signal representing `100`, then
`s.read(0)` returns `true`, and `s.read(1)` and `s.read(2)`
returns `false`.

Components all inherit from the abstract base class `Component`.
All components have an input width and an output width, which are
the widths of the signals that the component can read and produce
respectively. If `c` is a component and `s` is a signal, then
`c.process(s)` lets `c` read `s` and produce another signal as
output. For example, if `c` is an AND gate, and `s` is the signal
`10`, running `c.process(s)` will return the signal `0`. Trying to
process a signal that does not match the expected width throws an
`InvalidWidthException` (defined in its own class).

The library comes equipped with classes for the following gates:

- `IdentityGate` -- Reads and returns a signal of width one unchanged.
- `NotGate`      -- Reads and inverts a signal of width one.
- `AndGate`      -- Reads a signal `AB` and returns `A && B`
- `OrGate`       -- Reads a signal `AB` and returns `A || B`

All subclasses of `Component` inherit the same version of
`process` which performs checks that the widths of the input and
output signals match the input and output widths of the component.
The specialized behaviour of each subclass is instead implemented
in the method `processComponent`. This method **must** be
implemented by each subclass.

## Task

Your task is to implement two new components that can be used to
combine other components:

- A `Serial` component connects two components serially. For
  example, connecting an AND gate with a NOT gate serially creates
  a component with the following behaviour (the same as a NAND
  gate):

             +-------+    +-------+
      -------|       |    |       |
             |  AND  |----|  NOT  |----
      -------|       |    |       |
             +-------+    +-------+

  The input width of a serial component is the same as the input
  width of the first component. The output width is the same as
  the output width of the second component. The output width of
  the first component must match the input width of the second
  component, otherwise an `InvalidWidthException` should be thrown
  *on creation* of the invalid component (attaching an error
  message is optional).

- A `Parallel` component connects two components in parallel. For
  example, connecting an AND gate with a NOT gate in parallel
  creates a component with the following behaviour:


             +-------+
      -------|       |
             |  AND  |----
      -------|       |
             +-------+
             |       |
      -------|  NOT  |----
             |       |
             +-------+

  The input width of a parallel component is the sum of the input
  widths of both components. The output width is the sum of the
  output widths of both components.

Both of these components should be implemented as classes which
inherit from `Component`. In addition to any fields you want to
add, you need to implement reasonable constructors (which performs
the necessary super calls) and override the implementation of
`processSignal` to provide the expected behaviour. The file
`Driver.java` contains tests for the existing components as well
as for the components you are supposed to implement. The tests for
the latter are currently commented out so that the tests compile
on handout. You should uncomment the tests as your own
implementation progresses.

**Note that you should only hand in `Serial.java` and
`Parallel.java`. You should not change or hand in any other
files.**

When you have implemented everything and uncommented all the tests
in `Driver.java`, your output should look like this:

    $ make test
    javac *.java
    java Driver
    0 = 0
    1 = 1

    ~0 = 1
    ~1 = 0

    0 && 0 = 0
    0 && 1 = 0
    1 && 0 = 0
    1 && 1 = 1

    0 || 0 = 0
    0 || 1 = 1
    1 || 0 = 1
    1 || 1 = 1

    Sucessfully caught too wide signal
    Sucessfully caught to narrow width

    Below this line are the tests for what you should implement
    -----------------------------------------------------------
    ~(0 && 0) = 1
    ~(0 && 1) = 1
    ~(1 && 0) = 1
    ~(1 && 1) = 0

    ~(0 || 0) = 1
    ~(0 || 1) = 0
    ~(1 || 0) = 0
    ~(1 || 1) = 0

    Sucessfully caught plugging a narrow component into a wide

    ~10 = 01

    0 && 0 && 0 = 0
    0 && 0 && 1 = 0
    0 && 1 && 0 = 0
    0 && 1 && 1 = 0
    1 && 0 && 0 = 0
    1 && 0 && 1 = 0
    1 && 1 && 0 = 0
    1 && 1 && 1 = 1

    0 || 0 || 0 = 0
    0 || 0 || 1 = 1
    0 || 1 || 0 = 1
    0 || 1 || 1 = 1
    1 || 0 || 0 = 1
    1 || 0 || 1 = 1
    1 || 1 || 0 = 1
    1 || 1 || 1 = 1

    Sucessfully caught bad serial component

    -----------------------------------------------------------
    If you can read this and the output above looks right, you are *probably* done


## Files

- `Signal.java`    -- The class implementing signals.
- `Component.java` -- The base class of all components.
- `IdentityGate.java`, `NotGate.java`, `AndGate.java`, `OrGate.java` --
  The pre-existing components.
- `InvalidWidthException.java` -- The exception for invalid widths.
- `Driver.java`    -- A simple test program.
- `Serial.java`, `Parallel.java` -- This is where you should
  implement your solution.
- `Makefile` -- A (quite stupid) makefile that supports the following targets
  - `all`   -- Compile all the files
  - `test`  -- Build and run the tests
  - `clean` -- Remove any built files

## Pointers

- When you make your classes inherit from `Component` you may get
  a "strange" error message saying "constructor `Component` in
  class `Component` cannot be applied to given types". You solve
  this by adding a correct `super` call, first in your
  constructor. See the other gates for inspiration!
- You can also look at other gates to see how they implement their
  respective behaviour in the `processSignal` method.
- Although you really only need the `read` method of the `Signal`
  class and the constructor that takes an array of `boolean`s to
  solve the assignment, there are other useful methods in `Signal`
  that can make it easier. Read the code and the documentation!

## Handing in

You should hand in your solution via Studium.
