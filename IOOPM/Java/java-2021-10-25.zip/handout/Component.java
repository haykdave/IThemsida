/** The base class for components */
public abstract class Component {
    private final int inputWidth;
    private final int outputWidth;
    public Component(int inputWidth, int outputWidth) {
        this.inputWidth = inputWidth;
        this.outputWidth = outputWidth;
    }

    /** Get the required width of the input signal */
    public int getInputWidth() {
        return this.inputWidth;
    }

    /** Get the width of the output signal */
    public int getOutputWidth() {
        return this.outputWidth;
    }

    /** This is the method where subclasses implement how signals
     * are processed. */
    protected abstract Signal processSignal(Signal inputSignal);

    /** This is the common entry point for processing signals. It
     * perfoms a sanity check on the widths of the signals and the
     * widths of the component. The actual processing is
     * implemented by the `processSignal` method. */
    public final Signal process(Signal inputSignal) {
        if (inputSignal.getWidth() != this.inputWidth) {
            throw new InvalidWidthException(this + " expected width " + this.inputWidth + ". Got " + inputSignal.getWidth());
        } else {
            Signal outputSignal = this.processSignal(inputSignal);
            if (outputSignal.getWidth() != this.outputWidth) {
                throw new InvalidWidthException(this + " expected width " + this.outputWidth + ". Got " + outputSignal.getWidth());
            }
            return outputSignal;
        }
    }
}