/** A component implementing an AND gate */
public class AndGate extends Component {
    public AndGate() {
        super(2, 1);
    }

    protected Signal processSignal(Signal signal) {
        return Signal.build(signal.read(0) && signal.read(1));
    }
}
