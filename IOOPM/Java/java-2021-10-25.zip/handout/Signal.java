import java.util.Arrays;

/** A class that represents a number of signals (0s or 1s) on
 * parallel wires. */
public class Signal {
    private final boolean wires[];

    /** Construct a signal corresponding to the truth values in an
     * array. */
    public Signal(boolean wires[]) {
        this.wires = wires.clone();
    }

    /** Construct a signal which is a copy of another signal. */
    public Signal(Signal signal) {
        this(signal.wires.clone());
    }

    /** Construct a signal which is the parallel composition of
     * two signals. For examples, it turns the signals 10 and 01
     * into the signal 1001
     */
    public Signal(Signal signal1, Signal signal2) {
        this.wires = new boolean[signal1.getWidth() + signal2.getWidth()];
        for (int i = 0; i < signal1.getWidth(); i++) {
            this.wires[i] = signal1.read(i);
        }

        for (int i = 0; i < signal2.getWidth(); i++) {
            this.wires[i + signal1.getWidth()] = signal2.read(i);
        }
    }

    /** Get the number of wires in the signal. */
    public int getWidth() {
        return this.wires.length;
    }

    /** Get an array of truth-values corresponding to the the
     * number of wires in the signal. */
    public boolean read(int i) {
        return this.wires[i];
    }

    /** Split a signal into two signals (returned as an array of
     * length 2) at the given index. For example, splitting the
     * signal 1001 at index 2 returns the array {10, 01}.
     */
    public Signal[] split(int index) {
        return new Signal[] {new Signal(Arrays.copyOfRange(this.wires, 0, index))
                            ,new Signal(Arrays.copyOfRange(this.wires, index, this.getWidth()))
                            };
    }

    /** Get the string representation of a signal. */
    public String toString() {
        String s = "";
        for (boolean wire : wires) {
            if(wire) {
                s += "1";
            } else {
                s += "0";
            }
        }
        return s;
    }

    /** Helper function to build a signal from a variable list of
     * booleans. */
    public static Signal build(boolean... bs) {
        return new Signal(bs.clone());
    }

    /** Helper function to build a signal from a variable list of
     * ints (anything other than 0 will be interpreted as
     * true). */
    public static Signal build(int... ns) {
        boolean bs[] = new boolean[ns.length];
        for (int i = 0; i < ns.length; i++) {
            bs[i] = (ns[i] != 0);
        }
        return build(bs);
    }
}
