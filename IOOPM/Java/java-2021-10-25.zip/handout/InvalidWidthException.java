/** The exception thrown when two widths do not match. Can be
 * constructed with or without a message */
public class InvalidWidthException extends RuntimeException {
    String msg;
    public InvalidWidthException() {
        this.msg = msg;
    }

    public InvalidWidthException(String msg) {
        this.msg = msg;
    }
}