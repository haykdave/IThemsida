/** A component implementing a NOT gate */
public class NotGate extends Component {
    public NotGate() {
        super(1, 1);
    }

    protected Signal processSignal(Signal signal) {
        return Signal.build(!signal.read(0));
    }
}