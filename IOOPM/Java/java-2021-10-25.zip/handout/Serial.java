public class Serial { // TODO: Should inherit from Component
    // TODO: Write your solution here
}