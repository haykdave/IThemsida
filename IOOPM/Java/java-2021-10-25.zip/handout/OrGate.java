/** A component implementing an OR gate */
public class OrGate extends Component {
    public OrGate() {
        super(2, 1);
    }

    protected Signal processSignal(Signal signal) {
        return Signal.build(signal.read(0) || signal.read(1));
    }
}