/** A component implementing an identity gate */
public class IdentityGate extends Component {
    public IdentityGate() {
        super(1, 1);
    }

    protected Signal processSignal(Signal signal) {
        return new Signal(signal);
    }
}