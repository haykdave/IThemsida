/**
   A class for testing your code.
*/
public class Driver {
    /**
       Two overloaded helper functions for printing logic tables
    */
    public static void printTable(String symbol, int width, Component comp) {
        if (width == 1) {
            System.out.println(symbol + "0 = " + comp.process(Signal.build(0)));
            System.out.println(symbol + "1 = " + comp.process(Signal.build(1)));
        } else if (width == 2) {
            System.out.println("0 " + symbol + " 0 = " + comp.process(Signal.build(0, 0)));
            System.out.println("0 " + symbol + " 1 = " + comp.process(Signal.build(0, 1)));
            System.out.println("1 " + symbol + " 0 = " + comp.process(Signal.build(1, 0)));
            System.out.println("1 " + symbol + " 1 = " + comp.process(Signal.build(1, 1)));
        } else if (width == 3) {
            System.out.println("0 " + symbol + " 0 " + symbol + " 0 = "+ comp.process(Signal.build(0, 0, 0)));
            System.out.println("0 " + symbol + " 0 " + symbol + " 1 = "+ comp.process(Signal.build(0, 0, 1)));
            System.out.println("0 " + symbol + " 1 " + symbol + " 0 = "+ comp.process(Signal.build(0, 1, 0)));
            System.out.println("0 " + symbol + " 1 " + symbol + " 1 = "+ comp.process(Signal.build(0, 1, 1)));
            System.out.println("1 " + symbol + " 0 " + symbol + " 0 = "+ comp.process(Signal.build(1, 0, 0)));
            System.out.println("1 " + symbol + " 0 " + symbol + " 1 = "+ comp.process(Signal.build(1, 0, 1)));
            System.out.println("1 " + symbol + " 1 " + symbol + " 0 = "+ comp.process(Signal.build(1, 1, 0)));
            System.out.println("1 " + symbol + " 1 " + symbol + " 1 = "+ comp.process(Signal.build(1, 1, 1)));
        } else {
            throw new IllegalArgumentException();
        }
    }

    public static void printTable(String prefix, String symbol, int width, Component comp) {
        if (width == 1) {
            System.out.println(prefix + "(" + symbol + "0) = " + comp.process(Signal.build(0)));
            System.out.println(prefix + "(" + symbol + "1) = " + comp.process(Signal.build(1)));
        } else if (width == 2) {
            System.out.println(prefix + "(0 " + symbol + " 0) = " + comp.process(Signal.build(0, 0)));
            System.out.println(prefix + "(0 " + symbol + " 1) = " + comp.process(Signal.build(0, 1)));
            System.out.println(prefix + "(1 " + symbol + " 0) = " + comp.process(Signal.build(1, 0)));
            System.out.println(prefix + "(1 " + symbol + " 1) = " + comp.process(Signal.build(1, 1)));
        } else if (width == 3) {
            System.out.println(prefix + "(0 " + symbol + " 0 " + symbol + " 0) = "+ comp.process(Signal.build(0, 0, 0)));
            System.out.println(prefix + "(0 " + symbol + " 0 " + symbol + " 1) = "+ comp.process(Signal.build(0, 0, 1)));
            System.out.println(prefix + "(0 " + symbol + " 1 " + symbol + " 0) = "+ comp.process(Signal.build(0, 1, 0)));
            System.out.println(prefix + "(0 " + symbol + " 1 " + symbol + " 1) = "+ comp.process(Signal.build(0, 1, 1)));
            System.out.println(prefix + "(1 " + symbol + " 0 " + symbol + " 0) = "+ comp.process(Signal.build(1, 0, 0)));
            System.out.println(prefix + "(1 " + symbol + " 0 " + symbol + " 1) = "+ comp.process(Signal.build(1, 0, 1)));
            System.out.println(prefix + "(1 " + symbol + " 1 " + symbol + " 0) = "+ comp.process(Signal.build(1, 1, 0)));
            System.out.println(prefix + "(1 " + symbol + " 1 " + symbol + " 1) = "+ comp.process(Signal.build(1, 1, 1)));
        } else {
            throw new IllegalArgumentException();
        }
    }

    /**
       The main test method
    */
    public static void main(String[] args){
        try {
            // Create regular gates
            Component identityGate  = new IdentityGate();
            Component notGate       = new NotGate();
            Component andGate       = new AndGate();
            Component orGate        = new OrGate();

            printTable("", 1, identityGate);
            System.out.println("");

            printTable("~", 1, notGate);
            System.out.println("");

            printTable("&&", 2, andGate);
            System.out.println("");

            printTable("||", 2, orGate);
            System.out.println("");

            try {
                // Send a signal that is too wide
                identityGate.process(Signal.build(0, 0));
                System.out.println("========> Error: Could process a bad input signal");
            } catch (InvalidWidthException e) {
                System.out.println("Sucessfully caught too wide signal");
            }

            try {
                // Send a signal that is too wide
                andGate.process(Signal.build(0));
                System.out.println("========> Error: Could process a bad input signal");
            } catch (InvalidWidthException e) {
                System.out.println("Sucessfully caught to narrow width");
            }
            System.out.println("");

            System.out.println("Below this line are the tests for what you should implement");
            System.out.println("-----------------------------------------------------------");

            // TODO: Uncomment the tests as you go along to test your solution
            /*
            // Create serial gates
            Component nandGate = new Serial(new AndGate(), new NotGate());
            Component norGate  = new Serial(new OrGate(), new NotGate());

            printTable("~", "&&", 2, nandGate);
            System.out.println("");

            printTable("~", "||", 2, norGate);
            System.out.println("");

            try {
                // Create a serial component with non-matching width
                Component bad = new Serial(new NotGate(), new AndGate());
                System.out.println("========> Error: Could create a serial component");
            } catch (InvalidWidthException e) {
                System.out.println("Sucessfully caught plugging a narrow component into a wide");
                System.out.println("");
            }

            // Create parallel gates
            Component doubleNot = new Parallel(new NotGate(), new NotGate());
            System.out.println("~10 = " + doubleNot.process(Signal.build(1, 0)));
            System.out.println("");

            // Create parallel and serial gates
            Component and3Gate =
                new Serial(new Parallel(new AndGate(),
                                        new IdentityGate()),

                           new AndGate());

            Component or3Gate  =
                new Serial(new Parallel(new IdentityGate(),
                                        new OrGate()),
                           new OrGate());

            printTable("&&", 3, and3Gate);
            System.out.println("");

            printTable("||", 3, or3Gate);
            System.out.println("");

            try {
                // Create a serial component with non-matching width
                Component bad = new Serial(new AndGate(),
                                           new Parallel(new AndGate(),
                                                        new IdentityGate()));
                System.out.println("========> Error: Could create a bad serial component");
            } catch (InvalidWidthException e) {
                System.out.println("Sucessfully caught bad serial component");
                System.out.println("");
            }

            System.out.println("-----------------------------------------------------------");
            System.out.println("If you can read this and the output above looks right, you " +
                               "are *probably* done");
            */
        } catch (InvalidWidthException e) {
            System.out.println("=====> Caught an exception with the following message: " + e.msg);
            throw e;
        }
    }
}